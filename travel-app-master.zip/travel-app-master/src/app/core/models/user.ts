export interface IUser{
    displayName: string,
    email: string,
    uid:string,
    roles:string[],
}