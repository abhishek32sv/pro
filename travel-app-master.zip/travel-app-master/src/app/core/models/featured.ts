export interface IFeatured{
    id:string;
    destination:string;
    story:string,
    places:string[];
    image:string;
    reviews:Object[];
    likes:number;
}